import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialIcons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import DashboardScreen from './DashboardScreen';
import RequestsScreen from './Requests';
import EditProfileScreen from './EditProfileScreen';
import Logout from './Logout';

const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

// Bottom Tab Navigator for Home screen
function HomeTabs({ route }) {
  const { userID } = route.params || {};

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Dashboard') {
            iconName = 'dashboard';
          } else if (route.name === 'Requests') {
            iconName = 'person-add';
          }
          return <MaterialIcons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#4CAF50',
        tabBarInactiveTintColor: '#6B7280',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopColor: '#E5E7EB',
        },
        headerShown: false, // Hide tab navigator header to use drawer header
      })}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
        initialParams={{ userID }}
      />
      <Tab.Screen
        name="Requests"
        component={RequestsScreen}
        initialParams={{ userID }}
      />
    </Tab.Navigator>
  );
}

export default function MainDashboard({ route }) {
  const { userID } = route.params || {};

  if (!userID) {
    return <Text style={styles.errorText}>Error: No user ID provided.</Text>;
  }

  console.log('MainDashboard params:', userID);

  return (
    <Drawer.Navigator
      screenOptions={{
        headerTitleAlign: 'center',
        headerTitle: () => (
          <View style={styles.headerTitleContainer}>
            <Text style={styles.logoMini}>Skills</Text>
            <Text style={styles.logoMain}>Match</Text>
          </View>
        ),
        drawerActiveTintColor: '#4CAF50',
        drawerLabelStyle: { fontSize: 16 },
        headerTintColor: '#000',
      }}
    >
      <Drawer.Screen
        name="Home"
        component={HomeTabs}
        initialParams={{ userID }}
      />
      <Drawer.Screen
        name="EditProfileScreen"
        component={EditProfileScreen}
        initialParams={{ userID }}
      />
      <Drawer.Screen name="Logout" component={Logout} />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  headerTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoMini: {
    fontSize: 16,
    color: '#333',
    marginRight: -5.5,
    marginTop: 8,
  },
  logoMain: {
    fontSize: 27,
    color: '#4CAF50',
    fontWeight: 'bold',
    marginLeft: 4,
  },
  errorText: {
    fontSize: 16,
    color: '#FF0000',
    textAlign: 'center',
    margin: 20,
  },
});