import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useState } from 'react';
import { Alert, FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

export default function Requests({ route }) {
  const { userID } = route.params || {};
  const [followRequests, setFollowRequests] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchData() {
      if (!userID) {
        setError('Invalid user ID.');
        return;
      }

      try {
        // Fetch all users to map follower IDs to user data
        const usersResponse = await fetch(
          'https://matchmatchingsystem-default-rtdb.firebaseio.com/Users.json'
        );
        if (!usersResponse.ok) {
          throw new Error('Failed to fetch users.');
        }
        const usersData = await usersResponse.json();
        if (!usersData) {
          setError('No users found in the database.');
          setUsers([]);
          return;
        }
        const userArray = Object.keys(usersData).map((key) => ({
          id: key,
          ...usersData[key],
        }));
        setUsers(userArray);

        // Fetch follow requests for the current user
        const followRequestsResponse = await fetch(
          `https://matchmatchingsystem-default-rtdb.firebaseio.com/FollowRequests/${userID}.json`
        );
        if (!followRequestsResponse.ok) {
          throw new Error('Failed to fetch follow requests.');
        }
        const followRequestsData = await followRequestsResponse.json();
        const followRequestsArray = followRequestsData
          ? Object.keys(followRequestsData).map((key) => ({
              id: key,
              ...followRequestsData[key],
            }))
          : [];
        setFollowRequests(followRequestsArray);

        // Fetch followers list for the current user
        const followersResponse = await fetch(
          `https://matchmatchingsystem-default-rtdb.firebaseio.com/FollowRelationships/${userID}/followers.json`
        );
        if (!followersResponse.ok) {
          throw new Error('Failed to fetch followers list.');
        }
        const followersData = await followersResponse.json();
        setFollowers(followersData ? Object.keys(followersData) : []);

        setError('');
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load data. Please check your network and try again.');
      }
    }

    fetchData();
  }, [userID]);

  const handleAcceptRequest = async (senderID) => {
    try {
      const followingResponse = await fetch(
        `https://matchmatchingsystem-default-rtdb.firebaseio.com/FollowRelationships/${userID}/following/${senderID}.json`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ followedAt: new Date().toISOString() }),
        }
      );
      if (!followingResponse.ok) {
        throw new Error('Failed to update following list.');
      }

      const followersResponse = await fetch(
        `https://matchmatchingsystem-default-rtdb.firebaseio.com/FollowRelationships/${senderID}/followers/${userID}.json`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ followedAt: new Date().toISOString() }),
        }
      );
      if (!followersResponse.ok) {
        throw new Error('Failed to update followers list.');
      }

      const deleteResponse = await fetch(
        `https://matchmatchingsystem-default-rtdb.firebaseio.com/FollowRequests/${userID}/${senderID}.json`,
        {
          method: 'DELETE',
        }
      );
      if (!deleteResponse.ok) {
        throw new Error('Failed to delete follow request.');
      }

      setFollowRequests((prev) => prev.filter((req) => req.id !== senderID));
      setFollowers((prev) => [...prev, senderID]);
      console.log(`Follow request from ${senderID} accepted by ${userID}`);
      Alert.alert('Success', 'Follow request accepted!');
    } catch (err) {
      console.error('Error accepting follow request:', err);
      setError('Failed to accept follow request.');
    }
  };

  const handleRejectRequest = async (senderID) => {
    try {
      const response = await fetch(
        `https://matchmatchingsystem-default-rtdb.firebaseio.com/FollowRequests/${userID}/${senderID}.json`,
        {
          method: 'DELETE',
        }
      );
      if (!response.ok) {
        throw new Error('Failed to reject follow request.');
      }
      setFollowRequests((prev) => prev.filter((req) => req.id !== senderID));
      console.log(`Follow request from ${senderID} rejected by ${userID}`);
      Alert.alert('Success', 'Follow request rejected.');
    } catch (err) {
      console.error('Error rejecting follow request:', err);
      setError('Failed to reject follow request.');
    }
  };

  const followersData = users.filter((user) => followers.includes(user.id));

  const renderFollowRequest = ({ item }) => {
    // Find the sender's full user data from the users array
    const sender = users.find((user) => user.id === item.id) || {};
    return (
      <View style={styles.requestCard} accessible={true} accessibilityLabel={`Follow request from ${item.senderName}`}>
        <Image
          source={sender.image ? { uri: sender.image } : require('../../assets/images/favicon.png')}
          style={styles.userImage}
          accessibilityLabel={`${item.senderName}'s profile image`}
        />
        <View style={styles.userInfo}>
          <Text style={styles.userName}>{item.senderName || 'Unknown'}</Text>
          <View style={styles.userDetailRow}>
            <MaterialIcons name="location-pin" size={14} color="#6B7280" style={styles.userIcon} />
            <Text style={styles.userCity}>{sender.location || 'N/A'} | {sender.rating || 'N/A'} ★</Text>
          </View>
          <View style={styles.userDetailRow}>
            <MaterialIcons name="email" size={14} color="#6B7280" style={styles.userIcon} />
            <Text style={styles.userDetail}>{sender.email || 'N/A'}</Text>
          </View>
          <View style={styles.userDetailRow}>
            <MaterialIcons name="phone" size={14} color="#6B7280" style={styles.userIcon} />
            <Text style={styles.userDetail}>{sender.contact || 'N/A'}</Text>
          </View>
          <View style={styles.userDetailRow}>
            <MaterialIcons name="schedule" size={14} color="#6B7280" style={styles.userIcon} />
            <Text style={styles.userDetail}>{sender.availability || 'N/A'}</Text>
          </View>
          <View style={styles.userDetailRow}>
            <MaterialIcons name="build" size={14} color="#6B7280" style={styles.userIcon} />
            <Text style={styles.userSkills}>Skills: {sender.skillsHave?.join(', ') || 'N/A'}</Text>
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.acceptButton}
              onPress={() => handleAcceptRequest(item.id)}
              accessible={true}
              accessibilityLabel={`Accept follow request from ${item.senderName}`}
            >
              <Text style={styles.acceptButtonText}>Accept</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.rejectButton}
              onPress={() => handleRejectRequest(item.id)}
              accessible={true}
              accessibilityLabel={`Reject follow request from ${item.senderName}`}
            >
              <Text style={styles.rejectButtonText}>Reject</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  const renderFollower = ({ item }) => (
    <View style={styles.userCard} accessible={true} accessibilityLabel={`Follower ${item.name}`}>
      <Image
        source={item.image ? { uri: item.image } : require('../../assets/images/favicon.png')}
        style={styles.userImage}
        accessibilityLabel={`${item.name}'s profile image`}
      />
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{item.name}</Text>
        <View style={styles.userDetailRow}>
          <MaterialIcons name="location-pin" size={14} color="#6B7280" style={styles.userIcon} />
          <Text style={styles.userCity}>{item.location || 'N/A'} | {item.rating || 'N/A'} ★</Text>
        </View>
        <View style={styles.userDetailRow}>
          <MaterialIcons name="email" size={14} color="#6B7280" style={styles.userIcon} />
          <Text style={styles.userDetail}>{item.email || 'N/A'}</Text>
        </View>
        <View style={styles.userDetailRow}>
          <MaterialIcons name="phone" size={14} color="#6B7280" style={styles.userIcon} />
          <Text style={styles.userDetail}>{item.contact || 'N/A'}</Text>
        </View>
        <View style={styles.userDetailRow}>
          <MaterialIcons name="schedule" size={14} color="#6B7280" style={styles.userIcon} />
          <Text style={styles.userDetail}>{item.availability || 'N/A'}</Text>
        </View>
        <View style={styles.userDetailRow}>
          <MaterialIcons name="build" size={14} color="#6B7280" style={styles.userIcon} />
          <Text style={styles.userSkills}>Skills: {item.skillsHave?.join(', ') || 'N/A'}</Text>
        </View>
      </View>
    </View>
  );

  const data = [
    { type: 'header', id: 'header' },
    ...(followRequests.length > 0 ? [{ type: 'followRequestsTitle', id: 'followRequestsTitle' }, ...followRequests.map((req) => ({ type: 'followRequest', id: req.id, data: req }))] : []),
    ...(followersData.length > 0 ? [{ type: 'followersTitle', id: 'followersTitle' }, ...followersData.map((follower) => ({ type: 'follower', id: follower.id, data: follower }))] : []),
    ...(error ? [{ type: 'error', id: 'error', data: error }] : []),
  ];

  const renderItem = ({ item }) => {
    switch (item.type) {
      case 'header':
        return (
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Follow Requests & Followers</Text>
          </View>
        );
      case 'followRequestsTitle':
        return <Text style={styles.requestsTitle}>Follow Requests</Text>;
      case 'followRequest':
        return renderFollowRequest({ item: item.data });
      case 'followersTitle':
        return <Text style={styles.followersTitle}>My Followers</Text>;
      case 'follower':
        return renderFollower({ item: item.data });
      case 'error':
        return <Text style={styles.errorText}>{item.data}</Text>;
      default:
        return null;
    }
  };

  return (
    <LinearGradient
      colors={['#F0F4F8', '#D1DAE0']}
      style={styles.container}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContainer: {
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  header: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1E3A8A',
  },
  requestsTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1E3A8A',
    marginBottom: 10,
    marginTop: 10,
  },
  requestCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    marginBottom: 10,
  },
  userCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    marginBottom: 10,
  },
  userImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    marginRight: 15,
  },
  userInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  userName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 5,
  },
  userDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  userIcon: {
    marginRight: 8,
  },
  userCity: {
    fontSize: 14,
    color: '#6B7280',
  },
  userDetail: {
    fontSize: 14,
    color: '#374151',
  },
  userSkills: {
    fontSize: 14,
    color: '#374151',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 10,
  },
  acceptButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  acceptButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  rejectButton: {
    backgroundColor: '#FF0000',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginLeft: 10,
  },
  rejectButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  followersTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1E3A8A',
    marginBottom: 10,
    marginTop: 10,
  },
  errorText: {
    fontSize: 14,
    color: '#FF0000',
    textAlign: 'center',
    marginVertical: 10,
    fontWeight: '500',
  },
});