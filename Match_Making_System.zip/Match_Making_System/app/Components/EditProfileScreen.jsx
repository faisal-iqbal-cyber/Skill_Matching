import { useEffect, useState } from 'react';
import { Alert, Button, ScrollView, StyleSheet, Text, TextInput } from 'react-native';

export default function EditProfileScreen({ route, navigation }) {
  const { userID } = route.params || {};
  const [user, setUser] = useState(null);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    async function fetchUser() {
      if (!userID) {
        Alert.alert('Error', 'Invalid user ID.');
        navigation.goBack();
        return;
      }

      try {
        const res = await fetch(`https://matchmatchingsystem-default-rtdb.firebaseio.com/Users/${userID}.json`);
        if (!res.ok) {
          throw new Error('Failed to fetch user data.');
        }
        const data = await res.json();
        if (!data) {
          throw new Error('User data not found.');
        }
        setUser({
          ...data,
          skillsHave: data.skillsHave || [],
          skillsLearn: data.skillsLearn || [],
        });
      } catch (error) {
        Alert.alert('Error', 'Failed to load user data.');
        navigation.goBack();
      }
    }
    fetchUser();
  }, [userID, navigation]);

  const validateInputs = () => {
    const newErrors = {};
    if (!user?.name || user.name.trim() === '') {
      newErrors.name = 'Name is required.';
    }
    if (!user?.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)) {
      newErrors.email = 'Valid email is required.';
    }
    if (!user?.skillsHave || user.skillsHave.length === 0) {
      newErrors.skillsHave = 'At least one skill to offer is required.';
    }
    if (!user?.skillsLearn || user.skillsLearn.length === 0) {
      newErrors.skillsLearn = 'At least one skill to learn is required.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateInputs()) {
      Alert.alert('Error', 'Please fix the errors in the form.');
      return;
    }

    try {
      const response = await fetch(`https://matchmatchingsystem-default-rtdb.firebaseio.com/Users/${userID}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user),
      });
      if (!response.ok) {
        throw new Error('Failed to update profile.');
      }
      Alert.alert('Success', 'Profile updated successfully!', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile.');
    }
  };

  if (!user) return <Text style={styles.loadingText}>Loading...</Text>;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.label}>Name:</Text>
      <TextInput
        style={[styles.input, errors.name && styles.inputError]}
        value={user.name}
        onChangeText={(val) => setUser({ ...user, name: val })}
        placeholder="Enter your name"
        accessible={true}
        accessibilityLabel="Name input"
      />
      {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

      <Text style={styles.label}>Email:</Text>
      <TextInput
        style={[styles.input, errors.email && styles.inputError]}
        value={user.email}
        onChangeText={(val) => setUser({ ...user, email: val })}
        placeholder="Enter your email"
        keyboardType="email-address"
        accessible={true}
        accessibilityLabel="Email input"
      />
      {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

      <Text style={styles.label}>Location:</Text>
      <TextInput
        style={styles.input}
        value={user.location}
        onChangeText={(val) => setUser({ ...user, location: val })}
        placeholder="Enter your location"
        accessible={true}
        accessibilityLabel="Location input"
      />

      <Text style={styles.label}>Contact:</Text>
      <TextInput
        style={styles.input}
        value={user.contact}
        onChangeText={(val) => setUser({ ...user, contact: val })}
        placeholder="Enter your contact number"
        keyboardType="phone-pad"
        accessible={true}
        accessibilityLabel="Contact input"
      />

      <Text style={styles.label}>Availability:</Text>
      <TextInput
        style={styles.input}
        value={user.availability}
        onChangeText={(val) => setUser({ ...user, availability: val })}
        placeholder="Enter your availability"
        accessible={true}
        accessibilityLabel="Availability input"
      />

      <Text style={styles.label}>Skills I Can Offer (comma-separated):</Text>
      <TextInput
        style={[styles.input, errors.skillsHave && styles.inputError]}
        value={user.skillsHave?.join(', ') || ''}
        onChangeText={(val) => setUser({ ...user, skillsHave: val.split(',').map((s) => s.trim()).filter((s) => s) })}
        placeholder="e.g., JavaScript, Python"
        accessible={true}
        accessibilityLabel="Skills I can offer input"
      />
      {errors.skillsHave && <Text style={styles.errorText}>{errors.skillsHave}</Text>}

      <Text style={styles.label}>Skills I Want to Learn (comma-separated):</Text>
      <TextInput
        style={[styles.input, errors.skillsLearn && styles.inputError]}
        value={user.skillsLearn?.join(', ') || ''}
        onChangeText={(val) => setUser({ ...user, skillsLearn: val.split(',').map((s) => s.trim()).filter((s) => s) })}
        placeholder="e.g., React, Machine Learning"
        accessible={true}
        accessibilityLabel="Skills I want to learn input"
      />
      {errors.skillsLearn && <Text style={styles.errorText}>{errors.skillsLearn}</Text>}

      <Button title="Save Changes" onPress={handleSave} accessibilityLabel="Save profile changes" />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  label: {
    fontWeight: 'bold',
    marginTop: 10,
    fontSize: 16,
    color: '#1F2937',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 8,
    marginBottom: 10,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  inputError: {
    borderColor: '#FF0000',
  },
  errorText: {
    color: '#FF0000',
    fontSize: 14,
    marginBottom: 10,
  },
  loadingText: {
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
  },
});