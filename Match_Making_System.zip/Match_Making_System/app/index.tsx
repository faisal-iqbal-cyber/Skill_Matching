import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ChatScreen from './Components/ChatScreen';
import DashboardScreen from './Components/DashboardScreen';
import ForgotPassword from './Components/ForgotPassword';
import Login from './Components/Login';
import MainDashboard from './Components/MainDashboard';
import SignUp from './Components/SignUp';
import SplashScreen from './Components/SplashScreen';

const Stack = createNativeStackNavigator();

export default function Index() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SplashScreen" component={SplashScreen} />
      <Stack.Screen name="SignUp" component={SignUp} />
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="Dashboard" component={DashboardScreen} />
      <Stack.Screen name="ChatScreen" component={ChatScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
      <Stack.Screen name="MainDashboard" component={MainDashboard} />
    </Stack.Navigator>
  );
}